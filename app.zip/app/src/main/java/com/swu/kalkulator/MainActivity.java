package com.swu.kalkulator;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText editNum1, editNum2;
    Button buttonPlus, buttonMin, buttonMulti, buttonDiv, buttonCalc, buttonClear;
    TextView textResult;

    String operatorTerpilih = "";

    public static ArrayList<Riwayat> dataRiwayat = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNum1 = findViewById(R.id.editNum1);
        editNum2 = findViewById(R.id.editNum2);
        buttonPlus = findViewById(R.id.buttonPlus);
        buttonMin = findViewById(R.id.buttonMin);
        buttonMulti = findViewById(R.id.buttonMulti);
        buttonDiv = findViewById(R.id.buttonDiv);
        buttonCalc = findViewById(R.id.buttonCalc);
        buttonClear = findViewById(R.id.buttonClear);
        textResult = findViewById(R.id.textResult);

        buttonPlus.setOnClickListener(v -> {
            operatorTerpilih = "+";
            Toast.makeText(MainActivity.this, "Operator + dipilih", Toast.LENGTH_SHORT).show();
        });

        buttonMin.setOnClickListener(v -> {
            operatorTerpilih = "-";
            Toast.makeText(MainActivity.this, "Operator - dipilih", Toast.LENGTH_SHORT).show();
        });

        buttonMulti.setOnClickListener(v -> {
            operatorTerpilih = "x";
            Toast.makeText(MainActivity.this, "Operator x dipilih", Toast.LENGTH_SHORT).show();
        });

        buttonDiv.setOnClickListener(v -> {
            operatorTerpilih = ":";
            Toast.makeText(MainActivity.this, "Operator : dipilih", Toast.LENGTH_SHORT).show();
        });

        buttonCalc.setOnClickListener(v -> hitungHasil());

        buttonClear.setOnClickListener(v -> {
            editNum1.setText("");
            editNum2.setText("");
            textResult.setText("0");
            operatorTerpilih = "";
            editNum1.requestFocus();
        });
    }

    private void hitungHasil(){
        String input1 = editNum1.getText().toString();
        String input2 = editNum2.getText().toString();

        if(input1.isEmpty() || input2.isEmpty()){
            Toast.makeText(this, "Mohon isi kedua angka terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        if(operatorTerpilih.isEmpty()){
            Toast.makeText(this, "Mohon pilih operator terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        double angka1 = Double.parseDouble(input1);
        double angka2 = Double.parseDouble(input2);
        double hasil = 0;
        String teksPerhitungan = angka1 + " " + operatorTerpilih + " " + angka2;

        switch (operatorTerpilih){
            case "+":
                hasil = angka1 + angka2;
                break;
            case "-":
                hasil = angka1 - angka2;
                break;
            case "x":
                hasil = angka1 * angka2;
                break;
            case ":":
                if(angka2 == 0){
                    Toast.makeText(this, "Tidak bisa dibagi dengan angka 0!", Toast.LENGTH_SHORT).show();
                    return;
                }
                hasil = angka1 / angka2;
                break;
        }

        textResult.setText(String.valueOf(hasil));
        dataRiwayat.add(new Riwayat(teksPerhitungan, String.valueOf(hasil)));

        // --- FITUR INTENT TUGAS DOSEN ---
        if (hasil == 0.0) {
            // Jika hasil sama dengan 4, buka Kamera[cite: 8]
            Intent intentKamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivity(intentKamera);

        } else if (hasil == 3.0) {
            // Digit 3: Memutar suara/audio bawaan sistem HP
            Toast.makeText(this, "Sedang memutar audio...", Toast.LENGTH_SHORT).show();

            try {
                final android.media.MediaPlayer mediaPlayer = android.media.MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_RINGTONE_URI);
                if (mediaPlayer != null) {
                    mediaPlayer.start();

                    // Otomatis berhenti setelah 2 detik (2000 milidetik) agar tidak kepanjangan
                    new android.os.Handler().postDelayed(() -> {
                        if (mediaPlayer.isPlaying()) {
                            mediaPlayer.stop();
                        }
                        mediaPlayer.release();
                    }, 2000); // 2000 ms = 2 detik

                    mediaPlayer.setOnCompletionListener(mp -> mp.release());
                }
            } catch (Exception e) {
                Toast.makeText(this, "Gagal memutar audio", Toast.LENGTH_SHORT).show();
            }






        } else if (hasil == 8.0) {
            // Jika hasil saa dengan 8, buka Activity Image
            Intent intentGambar = new Intent(MainActivity.this, ImageActivity.class);
            startActivity(intentGambar);

        } else if (hasil == 1.0) {
            // Jika hasil sama dengan 5, buka Google Maps[cite: 8]
            String koordinat = "https://maps.app.goo.gl/LaCWtkeCih5ReLom6?g_st=aw";
            Intent intentMaps = new Intent(Intent.ACTION_VIEW, Uri.parse(koordinat));
            startActivity(intentMaps);


    } else if (hasil == 6.0) {
        // Digit 6: Membuka Activity Sensor (Accelerometer & Gyroscope)[cite: 1]
        Intent intentSensor = new Intent(MainActivity.this, SensorActivity.class);
        startActivity(intentSensor);
    }
    }
}